import { CartClient } from "@/components/cart/cart-client";

export default function CartPage() {
  return <CartClient />;
}